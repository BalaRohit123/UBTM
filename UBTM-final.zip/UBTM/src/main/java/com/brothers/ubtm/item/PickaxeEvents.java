package com.brothers.ubtm.item;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

public final class PickaxeEvents {
	private PickaxeEvents() {}

	public static void register() {
		PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, blockEntity) -> {
			if (!(level instanceof ServerLevel serverLevel)
					|| !(player instanceof ServerPlayer serverPlayer)) {
				return;
			}
			if (!com.brothers.ubtm.data.PlayerDataStore.get(serverPlayer).abilities) {
				return;
			}
			ItemStack tool = serverPlayer.getItemInHand(InteractionHand.MAIN_HAND);
			PickaxeAbility ability = ModItems.PICKAXE_ABILITIES.get(tool.getItem());
			if (ability != null) {
				ability.apply(serverLevel, serverPlayer, pos, state, blockEntity, tool);
			}
		});
	}
}
