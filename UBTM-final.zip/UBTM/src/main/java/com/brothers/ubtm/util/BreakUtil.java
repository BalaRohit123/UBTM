package com.brothers.ubtm.util;

import com.brothers.ubtm.UBTM;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Helpers for breaking extra blocks safely (no bedrock, no block entities, correct tool only). */
public final class BreakUtil {
	private BreakUtil() {}

	public static boolean isOre(BlockState state) {
		return BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath().endsWith("_ore");
	}

	/** Direction the player is looking, including straight up or down. */
	public static Direction lookDirection(ServerPlayer player) {
		float pitch = player.getXRot();
		if (pitch > 60) {
			return Direction.DOWN;
		}
		if (pitch < -60) {
			return Direction.UP;
		}
		return player.getDirection();
	}

	/** The (2r+1) x (2r+1) square of positions around center, perpendicular to the axis. */
	public static List<BlockPos> plane(BlockPos center, Direction.Axis axis, int r) {
		List<BlockPos> out = new ArrayList<>();
		for (int a = -r; a <= r; a++) {
			for (int b = -r; b <= r; b++) {
				if (a == 0 && b == 0) {
					continue;
				}
				switch (axis) {
					case X -> out.add(center.offset(0, a, b));
					case Y -> out.add(center.offset(a, 0, b));
					case Z -> out.add(center.offset(a, b, 0));
				}
			}
		}
		return out;
	}

	/** Breaks one extra block if the tool is the correct type for it. Returns true if broken. */
	public static boolean breakExtra(ServerLevel level, ServerPlayer player, BlockPos pos,
			ItemStack tool) {
		BlockState state = level.getBlockState(pos);
		if (state.isAir() || state.getDestroySpeed(level, pos) < 0
				|| state.hasBlockEntity() || !state.is(BlockTags.MINEABLE_WITH_PICKAXE)) {
			return false;
		}
		return destroy(level, player, pos, state, tool);
	}

	private static boolean destroy(ServerLevel level, ServerPlayer player, BlockPos pos,
			BlockState state, ItemStack tool) {
		if (state.getDestroySpeed(level, pos) < 0 || state.hasBlockEntity()) {
			return false;
		}
		BlockEntity be = level.getBlockEntity(pos);
		boolean drops = tool.isCorrectToolForDrops(state);
		level.destroyBlock(pos, false, player);
		if (drops) {
			Block.dropResources(state, level, pos, be, player, tool);
		}
		return true;
	}

	/** Breaks blocks of the same type connected to pos, up to max blocks. */
	public static void breakConnected(ServerLevel level, ServerPlayer player, BlockPos start,
			BlockState type, ItemStack tool, int max) {
		Set<BlockPos> seen = new HashSet<>();
		ArrayDeque<BlockPos> queue = new ArrayDeque<>();
		seen.add(start);
		queue.add(start);
		int broken = 0;
		while (!queue.isEmpty() && broken < max) {
			BlockPos cur = queue.poll();
			for (Direction d : Direction.values()) {
				BlockPos next = cur.relative(d);
				if (seen.add(next) && level.getBlockState(next).is(type.getBlock())) {
					BlockState s = level.getBlockState(next);
					if (destroy(level, player, next, s, tool)) {
						broken++;
						queue.add(next);
					}
					if (broken >= max) {
						break;
					}
				}
			}
		}
		if (broken > 0) {
			UBTM.LOGGER.debug("Connected break: {} blocks", broken);
		}
	}
}
