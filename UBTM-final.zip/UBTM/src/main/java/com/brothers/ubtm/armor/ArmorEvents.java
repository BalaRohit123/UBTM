package com.brothers.ubtm.armor;

import com.brothers.ubtm.data.PlayerDataStore;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;

/** Applies the set ability once per second while a full set is worn. */
public final class ArmorEvents {
	private ArmorEvents() {}

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTickCount() % 20 != 0) {
				return;
			}
			for (ServerPlayer p : server.getPlayerList().getPlayers()) {
				ArmorSet set = fullSet(p);
				if (set != null && PlayerDataStore.get(p).abilities) {
					set.applyTo(p);
				}
			}
		});
	}

	public static ArmorSet fullSet(ServerPlayer p) {
		Item head = p.getItemBySlot(EquipmentSlot.HEAD).getItem();
		ArmorSet set = ModArmor.SET_OF.get(head);
		if (set == null) {
			return null;
		}
		if (ModArmor.SET_OF.get(p.getItemBySlot(EquipmentSlot.CHEST).getItem()) == set
				&& ModArmor.SET_OF.get(p.getItemBySlot(EquipmentSlot.LEGS).getItem()) == set
				&& ModArmor.SET_OF.get(p.getItemBySlot(EquipmentSlot.FEET).getItem()) == set) {
			return set;
		}
		return null;
	}
}
