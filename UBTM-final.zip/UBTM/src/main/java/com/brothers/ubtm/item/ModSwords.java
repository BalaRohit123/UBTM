package com.brothers.ubtm.item;

import com.brothers.ubtm.UBTM;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.ItemLore;

/** Sword registry. IDs are unique (checked at startup). */
public final class ModSwords {
	public static final Map<String, Item> SWORDS = new LinkedHashMap<>();
	public static final Map<Item, SwordAbility> SWORD_ABILITIES = new HashMap<>();

	private ModSwords() {}

	public static void init() {
		sword("flame_brand", SwordAbility.FIRE, "Sets targets on fire for 6 seconds.", 1800, 3.0f, -2.4f, 15);
		sword("frost_fang", SwordAbility.FREEZE, "Freezes and slows the target.", 1700, 3.0f, -2.4f, 15);
		sword("venom_edge", SwordAbility.POISON, "Poisons the target for 6 seconds.", 1600, 3.0f, -2.4f, 14);
		sword("wither_reaper", SwordAbility.WITHER, "Inflicts Wither on the target.", 2000, 4.0f, -2.6f, 10);
		sword("vampire_blade", SwordAbility.LIFESTEAL, "Heals you by one heart per hit.", 1800, 3.0f, -2.4f, 14);
		sword("thunder_knock", SwordAbility.KNOCKBACK, "Launches targets away with huge knockback.", 1700, 3.0f, -2.6f, 12);
		sword("blind_blade", SwordAbility.BLIND, "Blinds the target for 5 seconds.", 1600, 3.0f, -2.4f, 14);
		sword("weakening_edge", SwordAbility.WEAKEN, "Weakness II on the target.", 1600, 3.0f, -2.4f, 14);
		sword("glow_sabre", SwordAbility.GLOW, "Makes the target glow for 20 seconds.", 1500, 2.0f, -2.2f, 18);
		sword("levitation_lance", SwordAbility.LEVITATE, "Lifts the target into the air.", 1500, 3.0f, -2.4f, 16);
		sword("nausea_saber", SwordAbility.NAUSEA, "Makes the target dizzy.", 1500, 3.0f, -2.4f, 14);
		sword("hunger_fang", SwordAbility.HUNGER, "Applies strong Hunger.", 1500, 3.0f, -2.4f, 14);
		sword("berserker", SwordAbility.BERSERK, "Strength II for 5 seconds after each hit.", 1900, 4.0f, -2.6f, 10);
		sword("swift_edge", SwordAbility.SWIFT, "Speed II for 5 seconds after each hit.", 1500, 2.0f, -1.8f, 16);
		sword("guardian_blade", SwordAbility.GUARD, "Grants Absorption hearts on hit.", 1900, 3.0f, -2.4f, 12);
		sword("regen_blade", SwordAbility.REGEN, "Regeneration II for 5 seconds on hit.", 1700, 3.0f, -2.4f, 14);
		sword("executioner", SwordAbility.EXECUTE, "Deals +6 damage to targets below 30% health.", 2100, 4.0f, -2.8f, 8);
		sword("critical_fang", SwordAbility.CRIT, "25% chance to deal +4 bonus damage.", 1700, 3.0f, -2.4f, 16);
		sword("chain_cleaver", SwordAbility.CLEAVE, "Also hits up to 3 nearby monsters.", 1900, 3.0f, -2.6f, 12);
		sword("shockwave_blade", SwordAbility.SHOCKWAVE, "Pushes all monsters within 5 blocks away.", 1800, 3.0f, -2.6f, 12);
		sword("slowing_sword", SwordAbility.SLOW, "Slowness IV on the target.", 1600, 3.0f, -2.4f, 14);
		sword("fatigue_fang", SwordAbility.FATIGUE, "Mining Fatigue on the target.", 1500, 3.0f, -2.4f, 14);
		sword("ghost_blade", SwordAbility.GHOST, "Turns you invisible for 5 seconds after a hit.", 1500, 3.0f, -2.2f, 16);
		sword("xp_thief", SwordAbility.XP_THIEF, "Drops bonus XP on every hit.", 1500, 2.0f, -2.2f, 25);
		sword("inferno_nova", SwordAbility.FIRE_NOVA, "Ignites every monster within 5 blocks.", 2200, 4.0f, -2.6f, 10);
		registerTab();
		UBTM.LOGGER.info("Registered {} swords", SWORDS.size());
	}

	private static void sword(String id, SwordAbility ability, String desc, int durability,
			float damage, float attackSpeed, int enchantability) {
		if (SWORDS.containsKey(id)) {
			throw new IllegalStateException("Duplicate sword id " + id);
		}
		ToolMaterial material = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, durability,
				8.0f, 0.0f, enchantability, ItemTags.DIAMOND_TOOL_MATERIALS);
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
				Identifier.fromNamespaceAndPath(UBTM.MOD_ID, id));
		Item item = new Item(new Item.Properties().setId(key)
				.sword(material, damage, attackSpeed)
				.component(DataComponents.LORE, new ItemLore(List.of(Component.literal(desc)))));
		Registry.register(BuiltInRegistries.ITEM, key, item);
		SWORDS.put(id, item);
		Info.DESC.put(id, desc);
		SWORD_ABILITIES.put(item, ability);
	}

	private static void registerTab() {
		ResourceKey<CreativeModeTab> key = ResourceKey.create(Registries.CREATIVE_MODE_TAB,
				Identifier.fromNamespaceAndPath(UBTM.MOD_ID, "swords"));
		CreativeModeTab tab = CreativeModeTab.builder(CreativeModeTab.Row.TOP, 6)
				.title(Component.translatable("itemGroup.ubtm.swords"))
				.icon(() -> new ItemStack(SWORDS.get("flame_brand")))
				.displayItems((params, output) -> {
					for (Item item : SWORDS.values()) {
						output.accept(item);
					}
				})
				.build();
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key, tab);
	}
}
