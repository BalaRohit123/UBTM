package com.brothers.ubtm.quest;

import com.brothers.ubtm.UBTM;
import com.brothers.ubtm.data.PlayerData;
import com.brothers.ubtm.data.PlayerDataStore;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

public final class QuestManager {
	private QuestManager() {}

	public static void init() {
		java.util.Set<String> seen = new java.util.HashSet<>();
		for (Quest q : QuestDefs.ALL) {
			if (!seen.add(q.id())) {
				throw new IllegalStateException("Duplicate quest id " + q.id());
			}
			if (q.type() != Quest.QuestType.TECH_COUNTER) {
				for (String t : q.target().split("\\|")) {
					boolean ok = q.type() == Quest.QuestType.MINE ? block(t) != Blocks.AIR : item(t) != Items.AIR;
					if (!ok) {
						throw new IllegalStateException("Quest " + q.id() + " has unknown target " + t);
					}
				}
			}
			for (Quest.Reward r : q.rewards()) {
				if (item(r.item()) == Items.AIR) {
					throw new IllegalStateException("Quest " + q.id() + " has unknown reward " + r.item());
				}
			}
		}
		if (QuestDefs.ALL.size() != 50) {
			throw new IllegalStateException("UBTM must have exactly 50 quests, found " + QuestDefs.ALL.size());
		}
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayer p = handler.getPlayer();
			ensureBaselines(p, PlayerDataStore.get(p));
		});
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
				PlayerDataStore.unload(server, handler.getPlayer().getUUID()));
		ServerLifecycleEvents.SERVER_STOPPING.register(PlayerDataStore::saveAll);
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTickCount() % 20 != 0) {
				return;
			}
			for (ServerPlayer p : server.getPlayerList().getPlayers()) {
				check(p);
			}
		});
		UBTM.LOGGER.info("Loaded {} quests", QuestDefs.ALL.size());
	}

	public static Item item(String id) {
		return BuiltInRegistries.ITEM.getValue(Identifier.parse(id));
	}

	public static Block block(String id) {
		return BuiltInRegistries.BLOCK.getValue(Identifier.parse(id));
	}

	private static int rawStat(ServerPlayer p, Quest q) {
		int total = 0;
		for (String t : q.target().split("\\|")) {
			switch (q.type()) {
				case MINE -> total += p.getStats().getValue(Stats.BLOCK_MINED.get(block(t)));
				case CRAFT -> total += p.getStats().getValue(Stats.ITEM_CRAFTED.get(item(t)));
				case TECH_USE -> total += p.getStats().getValue(Stats.ITEM_USED.get(item(t)));
				default -> { }
			}
		}
		return total;
	}

	private static void ensureBaselines(ServerPlayer p, PlayerData d) {
		for (Quest q : QuestDefs.ALL) {
			if (q.type() != Quest.QuestType.COLLECT && q.type() != Quest.QuestType.TECH_COUNTER) {
				d.baseline.putIfAbsent(q.id(), rawStat(p, q));
			}
		}
	}

	public static int progress(ServerPlayer p, PlayerData d, Quest q) {
		return switch (q.type()) {
			case COLLECT -> inventoryCount(p, q.target());
			case TECH_COUNTER -> d.counters.getOrDefault(q.target(), 0);
			default -> Math.max(0, rawStat(p, q) - d.baseline.getOrDefault(q.id(), 0));
		};
	}

	private static int inventoryCount(ServerPlayer p, String target) {
		Inventory inv = p.getInventory();
		int n = 0;
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack s = inv.getItem(i);
			for (String t : target.split("\\|")) {
				if (s.is(item(t))) {
					n += s.getCount();
				}
			}
		}
		return n;
	}

	public static void check(ServerPlayer p) {
		PlayerData d = PlayerDataStore.get(p);
		ensureBaselines(p, d);
		boolean changed = false;
		for (Quest q : QuestDefs.ALL) {
			if (!d.completed.contains(q.id()) && progress(p, d, q) >= q.count()) {
				d.completed.add(q.id());
				changed = true;
				p.sendSystemMessage(Component.literal("Quest complete: " + q.title()).withStyle(ChatFormatting.GREEN));
				for (Quest.Reward r : q.rewards()) {
					ItemStack stack = new ItemStack(item(r.item()), r.count());
					if (!p.addItem(stack)) {
						p.drop(stack, false);
					}
					p.sendSystemMessage(Component.literal("  Reward: " + r.count() + " x "
							+ stack.getHoverName().getString()).withStyle(ChatFormatting.YELLOW));
				}
			}
		}
		if (changed) {
			PlayerDataStore.save(p.level().getServer(), p.getUUID());
		}
	}
}
