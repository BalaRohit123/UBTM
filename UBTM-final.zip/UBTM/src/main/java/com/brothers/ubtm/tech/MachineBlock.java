package com.brothers.ubtm.tech;

import com.brothers.ubtm.data.PlayerData;
import com.brothers.ubtm.data.PlayerDataStore;
import com.brothers.ubtm.gui.Gui;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;

/** All UBTM machines. Each kind has its own behaviour. A redstone signal switches a machine off. */
public class MachineBlock extends Block {
	public enum Kind { MINING_MACHINE, AUTO_SMELTER, ORE_SCANNER, MINING_ROBOT, STORAGE_MACHINE, TERMINAL }

	public static final EnumProperty<Direction> FACING = BlockStateProperties.HORIZONTAL_FACING;

	private static final Map<Item, Item> SMELT = new LinkedHashMap<>();

	static {
		SMELT.put(Items.RAW_IRON, Items.IRON_INGOT);
		SMELT.put(Items.RAW_GOLD, Items.GOLD_INGOT);
		SMELT.put(Items.RAW_COPPER, Items.COPPER_INGOT);
		SMELT.put(Items.COBBLESTONE, Items.STONE);
		SMELT.put(Items.COBBLED_DEEPSLATE, Items.DEEPSLATE);
		SMELT.put(Items.SAND, Items.GLASS);
		SMELT.put(Items.CLAY_BALL, Items.BRICK);
		SMELT.put(Items.NETHERRACK, Items.NETHER_BRICK);
		SMELT.put(Items.OAK_LOG, Items.CHARCOAL);
		SMELT.put(Items.ANCIENT_DEBRIS, Items.NETHERITE_SCRAP);
		SMELT.put(Items.KELP, Items.DRIED_KELP);
		SMELT.put(Items.POTATO, Items.BAKED_POTATO);
		SMELT.put(Items.BEEF, Items.COOKED_BEEF);
		SMELT.put(Items.PORKCHOP, Items.COOKED_PORKCHOP);
		SMELT.put(Items.CHICKEN, Items.COOKED_CHICKEN);
		SMELT.put(Items.COD, Items.COOKED_COD);
		SMELT.put(Items.SALMON, Items.COOKED_SALMON);
	}

	private final Kind kind;

	public MachineBlock(Kind kind, Properties props) {
		super(props);
		this.kind = kind;
		registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	private boolean ticking() {
		return kind == Kind.MINING_MACHINE || kind == Kind.AUTO_SMELTER || kind == Kind.MINING_ROBOT;
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext ctx) {
		return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
	}

	@Override
	protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState,
			boolean movedByPiston) {
		super.onPlace(state, level, pos, oldState, movedByPiston);
		if (ticking() && level instanceof ServerLevel serverLevel) {
			serverLevel.scheduleTick(pos, this, 20);
		}
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
			Player player, BlockHitResult hit) {
		if (!(level instanceof ServerLevel serverLevel) || !(player instanceof ServerPlayer sp)) {
			return InteractionResult.SUCCESS;
		}
		PlayerData data = PlayerDataStore.get(sp);
		switch (kind) {
			case TERMINAL -> Gui.openMain(sp);
			case STORAGE_MACHINE -> {
				data.count("storage");
				sp.openMenu(new SimpleMenuProvider(
						(id, inv, p) -> ChestMenu.threeRows(id, inv, p.getEnderChestInventory()),
						Component.literal("Storage Machine")));
			}
			case ORE_SCANNER -> {
				data.count("scans");
				scan(serverLevel, sp, pos);
			}
			case MINING_MACHINE -> sp.sendSystemMessage(Component.literal(
					"Mining Machine: digs the 3x3 columns below it every 2 seconds. Redstone switches it off."), true);
			case AUTO_SMELTER -> sp.sendSystemMessage(Component.literal(
					"Auto Smelter: smelts items lying on top of it. Redstone switches it off."), true);
			case MINING_ROBOT -> sp.sendSystemMessage(Component.literal(
					"Mining Robot: tunnels forward (2 high) and moves with the tunnel. Redstone switches it off."), true);
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
		if (!ticking()) {
			return;
		}
		boolean moved = false;
		if (!level.hasNeighborSignal(pos)) {
			switch (kind) {
				case MINING_MACHINE -> mineBelow(level, pos);
				case AUTO_SMELTER -> smelt(level, pos);
				case MINING_ROBOT -> moved = robot(level, pos, state);
				default -> { }
			}
		}
		if (!moved) {
			level.scheduleTick(pos, this, kind == Kind.AUTO_SMELTER ? 20 : 40);
		}
	}

	private static boolean mineable(ServerLevel level, BlockPos p, BlockState st) {
		return !st.isAir() && st.getDestroySpeed(level, p) >= 0 && !st.hasBlockEntity()
				&& st.getFluidState().isEmpty();
	}

	private static void breakWithDrops(ServerLevel level, BlockPos p, BlockState st, BlockPos dropAt) {
		ItemStack tool = new ItemStack(Items.NETHERITE_PICKAXE);
		for (ItemStack drop : Block.getDrops(st, level, p, null, null, tool)) {
			Block.popResource(level, dropAt, drop);
		}
		level.destroyBlock(p, false);
	}

	private static void mineBelow(ServerLevel level, BlockPos pos) {
		for (int dy = 1; dy <= 32; dy++) {
			if (pos.getY() - dy < level.getMinY()) {
				return;
			}
			for (int dx = -1; dx <= 1; dx++) {
				for (int dz = -1; dz <= 1; dz++) {
					BlockPos p = pos.offset(dx, -dy, dz);
					if (!level.isLoaded(p)) {
						continue;
					}
					BlockState st = level.getBlockState(p);
					if (mineable(level, p, st)) {
						breakWithDrops(level, p, st, pos.above());
						return;
					}
				}
			}
		}
	}

	private static void smelt(ServerLevel level, BlockPos pos) {
		for (ItemEntity e : level.getEntitiesOfClass(ItemEntity.class, new AABB(pos.above()).inflate(0.2))) {
			ItemStack s = e.getItem();
			Item out = SMELT.get(s.getItem());
			if (out != null) {
				e.setItem(new ItemStack(out, s.getCount()));
			}
		}
	}

	/** Returns true if the robot moved (the old block is gone). */
	private static boolean robot(ServerLevel level, BlockPos pos, BlockState state) {
		Direction f = state.getValue(FACING);
		BlockPos front = pos.relative(f);
		if (!level.isLoaded(front) || !level.isLoaded(front.above())) {
			return false;
		}
		for (BlockPos p : List.of(front, front.above())) {
			BlockState st = level.getBlockState(p);
			if (!st.isAir()) {
				if (!mineable(level, p, st)) {
					return false;
				}
				breakWithDrops(level, p, st, pos.above());
			}
		}
		if (level.getBlockState(front).isAir()
				&& level.getBlockState(front.below()).isFaceSturdy(level, front.below(), Direction.UP)) {
			level.setBlock(front, state, Block.UPDATE_ALL);
			level.removeBlock(pos, false);
			return true;
		}
		return false;
	}

	private static void scan(ServerLevel level, ServerPlayer player, BlockPos pos) {
		final int r = 16;
		Map<String, Integer> counts = new LinkedHashMap<>();
		for (String k : List.of("Coal", "Iron", "Copper", "Gold", "Redstone", "Lapis", "Diamond",
				"Emerald", "Quartz", "Debris")) {
			counts.put(k, 0);
		}
		BlockPos nearestDiamond = null;
		for (BlockPos p : BlockPos.betweenClosed(pos.offset(-r, -r, -r), pos.offset(r, r, r))) {
			if (!level.isLoaded(p)) {
				continue;
			}
			BlockState st = level.getBlockState(p);
			String key = null;
			if (st.is(BlockTags.COAL_ORES)) {
				key = "Coal";
			} else if (st.is(BlockTags.IRON_ORES)) {
				key = "Iron";
			} else if (st.is(BlockTags.COPPER_ORES)) {
				key = "Copper";
			} else if (st.is(BlockTags.GOLD_ORES)) {
				key = "Gold";
			} else if (st.is(BlockTags.REDSTONE_ORES)) {
				key = "Redstone";
			} else if (st.is(BlockTags.LAPIS_ORES)) {
				key = "Lapis";
			} else if (st.is(BlockTags.DIAMOND_ORES)) {
				key = "Diamond";
				if (nearestDiamond == null || p.distSqr(pos) < nearestDiamond.distSqr(pos)) {
					nearestDiamond = p.immutable();
				}
			} else if (st.is(BlockTags.EMERALD_ORES)) {
				key = "Emerald";
			} else if (st.is(Blocks.NETHER_QUARTZ_ORE)) {
				key = "Quartz";
			} else if (st.is(Blocks.ANCIENT_DEBRIS)) {
				key = "Debris";
			}
			if (key != null) {
				counts.merge(key, 1, Integer::sum);
			}
		}
		StringBuilder sb = new StringBuilder("Ore scan (16 blocks): ");
		counts.forEach((k, v) -> sb.append(k).append(' ').append(v).append("  "));
		player.sendSystemMessage(Component.literal(sb.toString().trim()));
		if (nearestDiamond != null) {
			player.sendSystemMessage(Component.literal("Nearest diamond: " + nearestDiamond.getX() + " "
					+ nearestDiamond.getY() + " " + nearestDiamond.getZ()));
		}
	}
}
