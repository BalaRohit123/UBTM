package com.brothers.ubtm.armor;

import com.brothers.ubtm.UBTM;
import com.brothers.ubtm.armor.ArmorSet.Eff;
import com.brothers.ubtm.item.Info;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

/** 25 armour sets x 4 pieces. Each full set grants its own effects (see ArmorEvents). */
public final class ModArmor {
	public static final List<ArmorSet> SETS = new ArrayList<>();
	public static final Map<Item, ArmorSet> SET_OF = new HashMap<>();

	private ModArmor() {}

	private static Eff eff(Holder<MobEffect> effect, int amplifier) {
		return new Eff(effect, amplifier);
	}

	public static void init() {
		armor("miner_vigor", "Miner's Vigor", "Haste II and Night Vision.", 20, 2, 6, 5, 2, 0.0f, 0.0f, eff(MobEffects.HASTE, 1), eff(MobEffects.NIGHT_VISION, 0));
		armor("stoneheart", "Stoneheart", "Resistance II and Health Boost I.", 21, 2, 6, 5, 2, 0.0f, 0.0f, eff(MobEffects.RESISTANCE, 1), eff(MobEffects.HEALTH_BOOST, 0));
		armor("flame_ward", "Flame Ward", "Fire Resistance and Strength I.", 22, 2, 6, 5, 2, 0.0f, 0.0f, eff(MobEffects.FIRE_RESISTANCE, 0), eff(MobEffects.STRENGTH, 0));
		armor("tide_walker", "Tide Walker", "Water Breathing and Dolphin's Grace.", 23, 2, 6, 5, 2, 0.0f, 0.0f, eff(MobEffects.WATER_BREATHING, 0), eff(MobEffects.DOLPHINS_GRACE, 0));
		armor("sky_dancer", "Sky Dancer", "Jump Boost III and Slow Falling.", 24, 2, 6, 5, 2, 0.0f, 0.0f, eff(MobEffects.JUMP_BOOST, 2), eff(MobEffects.SLOW_FALLING, 0));
		armor("swift_runner", "Swift Runner", "Speed III and Jump Boost I.", 25, 3, 7, 6, 3, 0.5f, 0.0f, eff(MobEffects.SPEED, 2), eff(MobEffects.JUMP_BOOST, 0));
		armor("vital_guard", "Vital Guard", "Regeneration II and Absorption II.", 26, 3, 7, 6, 3, 0.5f, 0.0f, eff(MobEffects.REGENERATION, 1), eff(MobEffects.ABSORPTION, 1));
		armor("bulwark", "Bulwark", "Resistance III and Health Boost II.", 27, 3, 7, 6, 3, 0.5f, 0.0f, eff(MobEffects.RESISTANCE, 2), eff(MobEffects.HEALTH_BOOST, 1));
		armor("berserker_plate", "Berserker Plate", "Strength II and Speed I.", 28, 3, 7, 6, 3, 0.5f, 0.0f, eff(MobEffects.STRENGTH, 1), eff(MobEffects.SPEED, 0));
		armor("ghost_shroud", "Ghost Shroud", "Invisibility and Speed II.", 29, 3, 7, 6, 3, 0.5f, 0.0f, eff(MobEffects.INVISIBILITY, 0), eff(MobEffects.SPEED, 1));
		armor("lucky_charm", "Lucky Charm", "Luck III and Haste I.", 30, 4, 8, 7, 4, 1.0f, 0.0f, eff(MobEffects.LUCK, 2), eff(MobEffects.HASTE, 0));
		armor("abyss_diver", "Abyss Diver", "Conduit Power and Water Breathing.", 31, 4, 8, 7, 4, 1.0f, 0.0f, eff(MobEffects.CONDUIT_POWER, 0), eff(MobEffects.WATER_BREATHING, 0));
		armor("nourisher", "Nourisher", "Saturation and Regeneration I.", 32, 4, 8, 7, 4, 1.0f, 0.0f, eff(MobEffects.SATURATION, 0), eff(MobEffects.REGENERATION, 0));
		armor("titan", "Titan", "Health Boost IV and Resistance I.", 33, 4, 8, 7, 4, 1.0f, 0.0f, eff(MobEffects.HEALTH_BOOST, 3), eff(MobEffects.RESISTANCE, 0));
		armor("featherweight", "Featherweight", "Slow Falling and Speed II.", 34, 4, 8, 7, 4, 1.0f, 0.0f, eff(MobEffects.SLOW_FALLING, 0), eff(MobEffects.SPEED, 1));
		armor("prospector_gear", "Prospector Gear", "Haste III and Luck I.", 35, 5, 9, 8, 5, 1.5f, 0.1f, eff(MobEffects.HASTE, 2), eff(MobEffects.LUCK, 0));
		armor("lava_strider", "Lava Strider", "Fire Resistance, Resistance I and Speed I.", 36, 5, 9, 8, 5, 1.5f, 0.1f, eff(MobEffects.FIRE_RESISTANCE, 0), eff(MobEffects.RESISTANCE, 0), eff(MobEffects.SPEED, 0));
		armor("phantom", "Phantom", "Invisibility, Night Vision and Jump Boost I.", 37, 5, 9, 8, 5, 1.5f, 0.1f, eff(MobEffects.INVISIBILITY, 0), eff(MobEffects.NIGHT_VISION, 0), eff(MobEffects.JUMP_BOOST, 0));
		armor("gladiator", "Gladiator", "Strength II and Resistance I.", 38, 5, 9, 8, 5, 1.5f, 0.1f, eff(MobEffects.STRENGTH, 1), eff(MobEffects.RESISTANCE, 0));
		armor("sentinel", "Sentinel", "Absorption III and Night Vision.", 39, 5, 9, 8, 5, 1.5f, 0.1f, eff(MobEffects.ABSORPTION, 2), eff(MobEffects.NIGHT_VISION, 0));
		armor("lifebinder", "Lifebinder", "Health Boost II and Regeneration I.", 40, 6, 10, 9, 6, 2.0f, 0.1f, eff(MobEffects.HEALTH_BOOST, 1), eff(MobEffects.REGENERATION, 0));
		armor("stormcaller", "Stormcaller", "Speed II, Strength I and Haste I.", 41, 6, 10, 9, 6, 2.0f, 0.1f, eff(MobEffects.SPEED, 1), eff(MobEffects.STRENGTH, 0), eff(MobEffects.HASTE, 0));
		armor("glacier", "Glacier", "Resistance II and Fire Resistance.", 42, 6, 10, 9, 6, 2.0f, 0.1f, eff(MobEffects.RESISTANCE, 1), eff(MobEffects.FIRE_RESISTANCE, 0));
		armor("dragonscale", "Dragonscale", "Strength II, Resistance II and Fire Resistance.", 43, 6, 10, 9, 6, 2.0f, 0.1f, eff(MobEffects.STRENGTH, 1), eff(MobEffects.RESISTANCE, 1), eff(MobEffects.FIRE_RESISTANCE, 0));
		armor("ultimate_brother", "Ultimate Brother", "Haste II, Speed II, Strength II, Resistance II, Regeneration, Night Vision.", 44, 6, 10, 9, 6, 2.0f, 0.1f, eff(MobEffects.HASTE, 1), eff(MobEffects.SPEED, 1), eff(MobEffects.STRENGTH, 1), eff(MobEffects.RESISTANCE, 1), eff(MobEffects.REGENERATION, 0), eff(MobEffects.NIGHT_VISION, 0));
		registerTab();
		UBTM.LOGGER.info("Registered {} armour sets", SETS.size());
	}

	private static void armor(String id, String name, String desc, int durability, int helmet,
			int chest, int legs, int boots, float toughness, float knockback, Eff... effects) {
		for (ArmorSet s : SETS) {
			if (s.id().equals(id)) {
				throw new IllegalStateException("Duplicate armour set " + id);
			}
		}
		ResourceKey<EquipmentAsset> asset = ResourceKey.create(EquipmentAssets.ROOT_ID,
				Identifier.fromNamespaceAndPath(UBTM.MOD_ID, id));
		ArmorMaterial material = new ArmorMaterial(durability,
				Map.of(ArmorType.HELMET, helmet, ArmorType.CHESTPLATE, chest,
						ArmorType.LEGGINGS, legs, ArmorType.BOOTS, boots),
				15, SoundEvents.ARMOR_EQUIP_DIAMOND, toughness, knockback,
				ItemTags.REPAIRS_DIAMOND_ARMOR, asset);
		List<Item> pieces = new ArrayList<>();
		String[] names = {"helmet", "chestplate", "leggings", "boots"};
		ArmorType[] types = {ArmorType.HELMET, ArmorType.CHESTPLATE, ArmorType.LEGGINGS, ArmorType.BOOTS};
		for (int i = 0; i < 4; i++) {
			String pid = id + "_" + names[i];
			ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
					Identifier.fromNamespaceAndPath(UBTM.MOD_ID, pid));
			Item item = new Item(new Item.Properties().setId(key).humanoidArmor(material, types[i])
					.component(DataComponents.LORE, new ItemLore(List.of(
							Component.literal(name + " set bonus: " + desc)))));
			Registry.register(BuiltInRegistries.ITEM, key, item);
			pieces.add(item);
		}
		ArmorSet set = new ArmorSet(id, name, desc, List.of(effects), List.copyOf(pieces));
		SETS.add(set);
		for (Item p : pieces) {
			SET_OF.put(p, set);
		}
		Info.DESC.put(id, desc);
		Info.NAME.put(id, name);
	}

	private static void registerTab() {
		ResourceKey<CreativeModeTab> key = ResourceKey.create(Registries.CREATIVE_MODE_TAB,
				Identifier.fromNamespaceAndPath(UBTM.MOD_ID, "armour"));
		CreativeModeTab tab = CreativeModeTab.builder(CreativeModeTab.Row.TOP, 3)
				.title(Component.translatable("itemGroup.ubtm.armour"))
				.icon(() -> new ItemStack(SETS.get(0).pieces().get(1)))
				.displayItems((params, output) -> {
					for (ArmorSet s : SETS) {
						for (Item p : s.pieces()) {
							output.accept(p);
						}
					}
				})
				.build();
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key, tab);
	}
}
