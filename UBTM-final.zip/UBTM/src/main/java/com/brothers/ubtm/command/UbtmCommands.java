package com.brothers.ubtm.command;

import com.brothers.ubtm.armor.ArmorEvents;
import com.brothers.ubtm.armor.ArmorSet;
import com.brothers.ubtm.armor.ModArmor;
import com.brothers.ubtm.data.PlayerData;
import com.brothers.ubtm.data.PlayerDataStore;
import com.brothers.ubtm.gui.Gui;
import com.brothers.ubtm.hq.HqBuilder;
import com.brothers.ubtm.item.Info;
import com.brothers.ubtm.item.ModItems;
import com.brothers.ubtm.item.ModSwords;
import com.brothers.ubtm.quest.QuestDefs;
import com.brothers.ubtm.tech.ModTech;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public final class UbtmCommands {
	private static final int HQ_QUESTS_NEEDED = 10;

	private UbtmCommands() {}

	private static void say(CommandSourceStack src, String text) {
		src.sendSuccess(() -> Component.literal(text), false);
	}

	public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
		dispatcher.register(Commands.literal("ubtm")
				.executes(ctx -> gui(ctx.getSource()))
				.then(Commands.literal("gui").executes(ctx -> gui(ctx.getSource())))
				.then(Commands.literal("help").executes(ctx -> {
					say(ctx.getSource(), "UBTM commands:");
					say(ctx.getSource(), "/ubtm hq - build the underground testing HQ");
					say(ctx.getSource(), "/ubtm help - this list");
					say(ctx.getSource(), "/ubtm quests - open your quest list");
					say(ctx.getSource(), "/ubtm test - self-test and info about the item in your hand");
					say(ctx.getSource(), "/ubtm reload - save and reload player data");
					say(ctx.getSource(), "/ubtm gui - open the menu");
					return 1;
				}))
				.then(Commands.literal("hq").executes(ctx -> hq(ctx.getSource())))
				.then(Commands.literal("quests").executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					Gui.openQuests(p);
					return 1;
				}))
				.then(Commands.literal("test").executes(ctx -> test(ctx.getSource())))
				.then(Commands.literal("reload").executes(ctx -> {
					PlayerDataStore.reload(ctx.getSource().getServer());
					say(ctx.getSource(), "UBTM player data saved and reloaded.");
					return 1;
				})));
	}

	private static int gui(CommandSourceStack src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
		Gui.openMain(src.getPlayerOrException());
		return 1;
	}

	private static int hq(CommandSourceStack src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
		ServerPlayer p = src.getPlayerOrException();
		if (!(p.level() instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) {
			say(src, "The HQ can only be built in the Overworld.");
			return 0;
		}
		PlayerData d = PlayerDataStore.get(p);
		boolean creative = p.isCreative();
		if (!creative && d.completed.size() < HQ_QUESTS_NEEDED) {
			say(src, "Survival: complete " + HQ_QUESTS_NEEDED + " quests to unlock the HQ ("
					+ d.completed.size() + "/" + HQ_QUESTS_NEEDED + "). Creative players can build it any time.");
			return 0;
		}
		if (!HqBuilder.start(p, level, creative)) {
			say(src, "An HQ is already being built. Please wait.");
			return 0;
		}
		say(src, "Building the UBTM HQ at y=" + HqBuilder.FLOOR_Y + " (this takes a minute). Stay nearby.");
		return 1;
	}

	private static int test(CommandSourceStack src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
		ServerPlayer p = src.getPlayerOrException();
		int pieces = 0;
		for (ArmorSet s : ModArmor.SETS) {
			pieces += s.pieces().size();
		}
		boolean ok = ModItems.PICKAXES.size() == 25 && ModSwords.SWORDS.size() == 25
				&& ModArmor.SETS.size() == 25 && pieces == 100 && QuestDefs.ALL.size() == 50;
		say(src, "Self-test " + (ok ? "PASSED" : "FAILED") + ": " + ModItems.PICKAXES.size() + " pickaxes, "
				+ ModSwords.SWORDS.size() + " swords, " + ModArmor.SETS.size() + " armour sets (" + pieces
				+ " pieces), " + QuestDefs.ALL.size() + " quests, " + ModTech.ITEMS.size() + " tech items.");
		ItemStack held = p.getItemInHand(InteractionHand.MAIN_HAND);
		Item item = held.getItem();
		String key = BuiltInRegistries.ITEM.getKey(item).getPath();
		ArmorSet set = ModArmor.SET_OF.get(item);
		if (set != null) {
			say(src, "Held: " + set.name() + " set. Ability (full set): " + set.desc());
		} else if (Info.DESC.containsKey(key)) {
			say(src, "Held: " + Info.name(key) + ". Ability: " + Info.DESC.get(key));
		} else {
			say(src, "Hold a UBTM item to see its ability.");
		}
		ArmorSet worn = ArmorEvents.fullSet(p);
		if (worn != null) {
			say(src, "You are wearing the full " + worn.name() + " set.");
		}
		return ok ? 1 : 0;
	}
}
