package com.brothers.ubtm.tech;

import com.brothers.ubtm.UBTM;
import com.brothers.ubtm.item.Info;
import com.brothers.ubtm.item.ModItems;
import com.brothers.ubtm.item.PickaxeAbility;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** Technology: machines (blocks), the machine core and the electric drill. */
public final class ModTech {
	public static final Map<String, Block> BLOCKS = new LinkedHashMap<>();
	public static final List<Item> ITEMS = new ArrayList<>();

	private ModTech() {}

	public static void init() {
		machine("mining_machine", MachineBlock.Kind.MINING_MACHINE,
				"Digs the 3x3 columns below it every 2 seconds. Redstone turns it off.");
		machine("auto_smelter", MachineBlock.Kind.AUTO_SMELTER,
				"Smelts items lying on top of it. Redstone turns it off.");
		machine("ore_scanner", MachineBlock.Kind.ORE_SCANNER,
				"Right-click to scan 16 blocks for ores and find the nearest diamond.");
		machine("mining_robot", MachineBlock.Kind.MINING_ROBOT,
				"Tunnels forward 2 high and moves along. Redstone turns it off.");
		machine("storage_machine", MachineBlock.Kind.STORAGE_MACHINE,
				"Right-click to open your personal 27-slot storage anywhere.");
		machine("ubtm_terminal", MachineBlock.Kind.TERMINAL,
				"Right-click to open the UBTM menu.");
		simple("machine_core", "Crafting component for all UBTM machines.");
		drill();
		registerTab();
		UBTM.LOGGER.info("Registered {} technology items", ITEMS.size());
	}

	private static ResourceKey<Item> itemKey(String id) {
		return ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(UBTM.MOD_ID, id));
	}

	private static void machine(String id, MachineBlock.Kind kind, String desc) {
		ResourceKey<Block> bk = ResourceKey.create(Registries.BLOCK,
				Identifier.fromNamespaceAndPath(UBTM.MOD_ID, id));
		Block block = new MachineBlock(kind, BlockBehaviour.Properties.of().strength(3.5f)
				.sound(SoundType.METAL).requiresCorrectToolForDrops().setId(bk));
		Registry.register(BuiltInRegistries.BLOCK, bk, block);
		ResourceKey<Item> ik = itemKey(id);
		Item item = new BlockItem(block, new Item.Properties().setId(ik).useBlockDescriptionPrefix()
				.component(DataComponents.LORE, new ItemLore(List.of(Component.literal(desc)))));
		Registry.register(BuiltInRegistries.ITEM, ik, item);
		BLOCKS.put(id, block);
		ITEMS.add(item);
		Info.DESC.put(id, desc);
	}

	private static void simple(String id, String desc) {
		ResourceKey<Item> ik = itemKey(id);
		Item item = new Item(new Item.Properties().setId(ik)
				.component(DataComponents.LORE, new ItemLore(List.of(Component.literal(desc)))));
		Registry.register(BuiltInRegistries.ITEM, ik, item);
		ITEMS.add(item);
		Info.DESC.put(id, desc);
	}

	private static void drill() {
		String id = "electric_drill";
		String desc = "Electric Drill: breaks a 3x3 area in the direction you face.";
		ToolMaterial material = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 3200,
				12.0f, 0.0f, 15, ItemTags.DIAMOND_TOOL_MATERIALS);
		ResourceKey<Item> ik = itemKey(id);
		Item item = new Item(new Item.Properties().setId(ik).pickaxe(material, 2.0f, -2.8f)
				.component(DataComponents.LORE, new ItemLore(List.of(Component.literal(desc)))));
		Registry.register(BuiltInRegistries.ITEM, ik, item);
		ModItems.PICKAXE_ABILITIES.put(item, PickaxeAbility.HAMMER);
		ITEMS.add(item);
		Info.DESC.put(id, desc);
	}

	private static void registerTab() {
		ResourceKey<CreativeModeTab> key = ResourceKey.create(Registries.CREATIVE_MODE_TAB,
				Identifier.fromNamespaceAndPath(UBTM.MOD_ID, "technology"));
		CreativeModeTab tab = CreativeModeTab.builder(CreativeModeTab.Row.TOP, 4)
				.title(Component.translatable("itemGroup.ubtm.technology"))
				.icon(() -> new ItemStack(ITEMS.get(0)))
				.displayItems((params, output) -> {
					for (Item item : ITEMS) {
						output.accept(item);
					}
				})
				.build();
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key, tab);
	}
}
