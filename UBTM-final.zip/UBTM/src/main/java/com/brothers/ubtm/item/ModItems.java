package com.brothers.ubtm.item;

import com.brothers.ubtm.UBTM;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.ToolMaterial;

/** Item registry. Generated item IDs are unique (checked at startup). */
public final class ModItems {
	public static final Map<String, Item> PICKAXES = new LinkedHashMap<>();
	public static final Map<Item, PickaxeAbility> PICKAXE_ABILITIES = new HashMap<>();

	private ModItems() {}

	public static void init() {
		pickaxe("vein_reaper", PickaxeAbility.VEIN_MINER, "Mines whole ore veins (up to 24 blocks).", 1800, 9.0f, 1.0f, 15);
		pickaxe("titan_hammer", PickaxeAbility.HAMMER, "Breaks a 3x3 area in the direction you face.", 2200, 8.0f, 2.0f, 10);
		pickaxe("tunnel_borer", PickaxeAbility.TUNNEL, "Digs 5 blocks deep in the direction you face.", 1900, 8.5f, 1.0f, 12);
		pickaxe("ember_smelter", PickaxeAbility.SMELTER, "Auto-smelts raw ores, cobblestone and sand.", 1600, 8.0f, 1.0f, 14);
		pickaxe("magnet_pick", PickaxeAbility.MAGNET, "Pulls drops straight to you.", 1500, 8.0f, 1.0f, 16);
		pickaxe("haste_surge", PickaxeAbility.HASTE, "Haste II for 5 seconds after each block.", 1400, 10.0f, 0.5f, 18);
		pickaxe("timberbreaker", PickaxeAbility.LUMBER, "Fells connected logs (up to 64).", 1700, 8.0f, 1.5f, 12);
		pickaxe("deep_sight", PickaxeAbility.NIGHT_VISION, "Night Vision while you mine.", 1500, 8.0f, 1.0f, 15);
		pickaxe("prospector", PickaxeAbility.XP_BOOST, "Drops +3 bonus XP for every block.", 1600, 8.0f, 1.0f, 20);
		pickaxe("fortune_fang", PickaxeAbility.LUCKY, "10% chance to double a block's drops.", 1800, 8.0f, 1.0f, 22);
		pickaxe("torchbearer", PickaxeAbility.TORCH, "Places a torch in dark spots as you mine.", 1500, 8.0f, 1.0f, 12);
		pickaxe("vital_pick", PickaxeAbility.HEAL, "Heals half a heart per block.", 1500, 8.0f, 1.0f, 14);
		pickaxe("swiftfoot", PickaxeAbility.SPEED, "Speed II for 3 seconds after each block.", 1400, 9.0f, 0.5f, 15);
		pickaxe("skyleap", PickaxeAbility.JUMP, "Jump Boost II for 5 seconds.", 1400, 8.0f, 0.5f, 15);
		pickaxe("magma_pick", PickaxeAbility.FIRE_RESIST, "Fire Resistance for 10 seconds.", 1700, 8.0f, 1.5f, 12);
		pickaxe("tidal_pick", PickaxeAbility.WATER_BREATH, "Water Breathing for 10 seconds.", 1500, 8.0f, 1.0f, 14);
		pickaxe("cube_crusher", PickaxeAbility.EXCAVATOR, "Breaks a 3x3x3 cube around the block.", 2400, 7.5f, 2.0f, 8);
		pickaxe("radar_pick", PickaxeAbility.SCANNER, "Shows ore count within 8 blocks on mining.", 1500, 8.0f, 1.0f, 18);
		pickaxe("beacon_pick", PickaxeAbility.GLOW, "Makes monsters within 12 blocks glow.", 1500, 8.0f, 1.0f, 14);
		pickaxe("skybreaker", PickaxeAbility.COLUMN_UP, "Breaks 4 blocks upward.", 1800, 8.5f, 1.0f, 12);
		pickaxe("deepdelver", PickaxeAbility.COLUMN_DOWN, "Breaks 4 blocks downward.", 1800, 8.5f, 1.0f, 12);
		pickaxe("mender_pick", PickaxeAbility.REPAIR, "10% chance to repair 2 durability per block.", 1300, 8.0f, 1.0f, 16);
		pickaxe("bulwark_pick", PickaxeAbility.RESIST, "Resistance I for 5 seconds.", 1900, 7.5f, 1.5f, 10);
		pickaxe("treasure_hunter", PickaxeAbility.TREASURE, "2% chance to find a diamond.", 1600, 8.0f, 1.0f, 25);
		pickaxe("inferno_pick", PickaxeAbility.FIRE_AURA, "Ignites monsters within 6 blocks.", 2000, 8.0f, 2.0f, 12);
		UBTM.LOGGER.info("Registered {} pickaxes", PICKAXES.size());
	}

	private static void pickaxe(String id, PickaxeAbility ability, String desc, int durability,
			float speed, float damage, int enchantability) {
		if (PICKAXES.containsKey(id)) {
			throw new IllegalStateException("Duplicate pickaxe id " + id);
		}
		ToolMaterial material = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, durability,
				speed, 0.0f, enchantability, ItemTags.DIAMOND_TOOL_MATERIALS);
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
				Identifier.fromNamespaceAndPath(UBTM.MOD_ID, id));
		Item item = new Item(new Item.Properties().setId(key)
				.pickaxe(material, damage, -2.8f)
				.component(DataComponents.LORE, new ItemLore(List.of(Component.literal(desc)))));
		Registry.register(BuiltInRegistries.ITEM, key, item);
		PICKAXES.put(id, item);
		Info.DESC.put(id, desc);
		PICKAXE_ABILITIES.put(item, ability);
	}

	public static List<Item> allPickaxes() {
		return new ArrayList<>(PICKAXES.values());
	}
}
