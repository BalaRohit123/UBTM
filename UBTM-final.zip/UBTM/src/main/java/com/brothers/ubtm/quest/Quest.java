package com.brothers.ubtm.quest;

import java.util.List;

/**
 * One quest. For MINE/CRAFT/TECH_USE/COLLECT the target is one or more item or block ids
 * separated by '|' (their counts are added together). For TECH_COUNTER it is a counter name.
 */
public record Quest(String id, QuestType type, String category, String title, String desc,
		String target, int count, List<Reward> rewards) {

	public enum QuestType { MINE, CRAFT, COLLECT, TECH_USE, TECH_COUNTER }

	public record Reward(String item, int count) {}
}
