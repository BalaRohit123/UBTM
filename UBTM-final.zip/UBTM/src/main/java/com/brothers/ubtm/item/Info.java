package com.brothers.ubtm.item;

import java.util.HashMap;
import java.util.Map;

/** Ability descriptions and display names used by the GUI, HQ rooms and /ubtm test. */
public final class Info {
	public static final Map<String, String> DESC = new HashMap<>();
	public static final Map<String, String> NAME = new HashMap<>();

	private Info() {}

	public static String pretty(String id) {
		StringBuilder sb = new StringBuilder();
		for (String part : id.split("_")) {
			if (!part.isEmpty()) {
				sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(' ');
			}
		}
		return sb.toString().trim();
	}

	public static String name(String id) {
		return NAME.getOrDefault(id, pretty(id));
	}
}
