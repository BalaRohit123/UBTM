package com.brothers.ubtm.gui;

import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

/** A chest-style menu where slots are buttons. Nothing can be taken out of it. */
public final class UbtmMenu extends ChestMenu {
	private final Map<Integer, Consumer<ServerPlayer>> actions;
	private final int size;

	public UbtmMenu(int id, Inventory inv, SimpleContainer container, int rows,
			Map<Integer, Consumer<ServerPlayer>> actions) {
		super(rows == 3 ? MenuType.GENERIC_9x3 : MenuType.GENERIC_9x6, id, inv, container, rows);
		this.actions = actions;
		this.size = rows * 9;
	}

	@Override
	public void clicked(int slotId, int button, ClickType clickType, Player player) {
		if (slotId >= 0 && slotId < size && player instanceof ServerPlayer sp) {
			Consumer<ServerPlayer> action = actions.get(slotId);
			if (action != null) {
				action.accept(sp);
			}
		}
		sendAllDataToRemote();
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		return ItemStack.EMPTY;
	}
}
