package com.brothers.ubtm;

import com.brothers.ubtm.armor.ArmorEvents;
import com.brothers.ubtm.armor.ModArmor;
import com.brothers.ubtm.command.UbtmCommands;
import com.brothers.ubtm.hq.HqBuilder;
import com.brothers.ubtm.item.ModItems;
import com.brothers.ubtm.item.ModSwords;
import com.brothers.ubtm.item.ModTabs;
import com.brothers.ubtm.item.PickaxeEvents;
import com.brothers.ubtm.item.SwordEvents;
import com.brothers.ubtm.quest.QuestManager;
import com.brothers.ubtm.tech.ModTech;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UBTM implements ModInitializer {
	public static final String MOD_ID = "ubtm";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ModItems.init();
		ModTabs.init();
		ModSwords.init();
		ModArmor.init();
		ModTech.init();
		QuestManager.init();
		PickaxeEvents.register();
		SwordEvents.register();
		ArmorEvents.register();
		HqBuilder.register();
		CommandRegistrationCallback.EVENT.register(
				(dispatcher, buildContext, selection) -> UbtmCommands.register(dispatcher));
		LOGGER.info("UBTM loaded");
	}
}
