package com.brothers.ubtm.item;

import com.brothers.ubtm.UBTM;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class ModTabs {
	private ModTabs() {}

	public static void init() {
		ResourceKey<CreativeModeTab> key = ResourceKey.create(Registries.CREATIVE_MODE_TAB,
				Identifier.fromNamespaceAndPath(UBTM.MOD_ID, "pickaxes"));
		CreativeModeTab tab = CreativeModeTab.builder(CreativeModeTab.Row.TOP, 5)
				.title(Component.translatable("itemGroup.ubtm.pickaxes"))
				.icon(() -> new ItemStack(ModItems.PICKAXES.get("vein_reaper")))
				.displayItems((params, output) -> {
					for (Item item : ModItems.PICKAXES.values()) {
						output.accept(item);
					}
				})
				.build();
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key, tab);
	}
}
