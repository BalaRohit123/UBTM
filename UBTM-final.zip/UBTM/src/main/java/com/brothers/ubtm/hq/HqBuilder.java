package com.brothers.ubtm.hq;

import com.brothers.ubtm.armor.ArmorSet;
import com.brothers.ubtm.armor.ModArmor;
import com.brothers.ubtm.item.Info;
import com.brothers.ubtm.item.ModItems;
import com.brothers.ubtm.item.ModSwords;
import com.brothers.ubtm.tech.ModTech;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Builds the underground headquarters. Work is split into small steps that run a few per tick so
 * the server never freezes while chunks load.
 *
 * Layout (all relative to the player's position, floor at FLOOR_Y):
 *   Control room, a west lab corridor with 5 labs, a north-south connector, and three long
 *   corridors with 25 rooms each (pickaxes, swords, armour).
 */
public final class HqBuilder {
	public static final int FLOOR_Y = -52;
	private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;
	private static final int ROOMS = 25;
	private static final int SPACING = 12;

	private static final ArrayDeque<Runnable> QUEUE = new ArrayDeque<>();
	private static ServerLevel level;
	private static int ox;
	private static int oz;
	private static boolean creativeBuild;
	private static UUID requester;
	private static int total;
	private static int lastReported;
	private static boolean registered;

	private static final BlockState AIR = Blocks.AIR.defaultBlockState();
	private static final BlockState WALL = Blocks.STONE_BRICKS.defaultBlockState();
	private static final BlockState LAMP = Blocks.SEA_LANTERN.defaultBlockState();

	private HqBuilder() {}

	public static boolean busy() {
		return !QUEUE.isEmpty();
	}

	public static void register() {
		if (registered) {
			return;
		}
		registered = true;
		ServerTickEvents.END_SERVER_TICK.register(HqBuilder::tick);
	}

	private static void tick(MinecraftServer server) {
		if (QUEUE.isEmpty()) {
			return;
		}
		long deadline = System.nanoTime() + 35_000_000L;
		while (!QUEUE.isEmpty() && System.nanoTime() < deadline) {
			QUEUE.poll().run();
		}
		int done = total - QUEUE.size();
		int pct = total == 0 ? 100 : done * 100 / total;
		ServerPlayer p = requester == null ? null : server.getPlayerList().getPlayer(requester);
		if (p != null && pct / 10 != lastReported / 10) {
			p.sendSystemMessage(Component.literal("HQ building: " + pct + "%"));
		}
		lastReported = pct;
		if (QUEUE.isEmpty() && p != null) {
			p.sendSystemMessage(Component.literal("UBTM HQ is ready. Control room is "
					+ "west of you at the entrance; labs lie further west, test rooms east."));
		}
	}

	/** Queues the whole build. Returns false if a build is already running. */
	public static boolean start(ServerPlayer player, ServerLevel lvl, boolean creative) {
		if (busy()) {
			return false;
		}
		level = lvl;
		ox = player.blockPosition().getX();
		oz = player.blockPosition().getZ();
		creativeBuild = creative;
		requester = player.getUUID();
		lastReported = 0;
		register();

		// connector corridor (north-south) and the three room corridors
		QUEUE.add(() -> corridor(-5, -2, -1, 73));
		for (int c = 0; c < 3; c++) {
			final int zc = 30 * c;
			final int end = SPACING * ROOMS + 2;
			QUEUE.add(() -> corridor(-1, zc + 8, end, zc + 12));
		}
		// control room and lab corridor
		QUEUE.add(HqBuilder::controlRoom);
		QUEUE.add(() -> corridor(-96, 34, -26, 38));
		QUEUE.add(() -> carve(-6, 35, -5, 37));
		QUEUE.add(() -> carve(-27, 35, -26, 37));
		for (int c = 0; c < 3; c++) {
			final int zc = 30 * c;
			QUEUE.add(() -> carve(-2, zc + 9, -1, zc + 11));
		}
		// labs
		for (int i = 0; i < 5; i++) {
			final int lab = i;
			QUEUE.add(() -> lab(lab));
		}
		// 75 rooms, one per tick-step
		for (int k = 0; k < ROOMS; k++) {
			final int idx = k;
			QUEUE.add(() -> toolRoom(0, idx));
			QUEUE.add(() -> toolRoom(1, idx));
			QUEUE.add(() -> toolRoom(2, idx));
		}
		total = QUEUE.size();
		return true;
	}

	// ----- block helpers (x and z are relative to the player, y is absolute) -----

	private static void set(int x, int y, int z, BlockState s) {
		level.setBlock(new BlockPos(ox + x, y, oz + z), s, FLAGS);
	}

	private static void fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
		BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
		for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
			for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
				for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
					level.setBlock(m.set(ox + x, y, oz + z), s, FLAGS);
				}
			}
		}
	}

	/** Walls, floor, ceiling and lights; interior is x1+1..x2-1, z1+1..z2-1. */
	private static void shell(int x1, int z1, int x2, int z2, BlockState wall, BlockState floor) {
		fill(x1, FLOOR_Y - 1, z1, x2, FLOOR_Y + 7, z2, wall);
		fill(x1 + 1, FLOOR_Y + 1, z1 + 1, x2 - 1, FLOOR_Y + 6, z2 - 1, AIR);
		fill(x1 + 1, FLOOR_Y, z1 + 1, x2 - 1, FLOOR_Y, z2 - 1, floor);
		for (int x = x1 + 1; x <= x2 - 1; x++) {
			for (int z = z1 + 1; z <= z2 - 1; z++) {
				if ((x - x1) % 4 == 2 && (z - z1) % 4 == 2) {
					set(x, FLOOR_Y + 7, z, LAMP);
				}
			}
		}
	}

	private static void corridor(int x1, int z1, int x2, int z2) {
		shell(x1, z1, x2, z2, WALL, Blocks.SMOOTH_STONE.defaultBlockState());
	}

	/** Opens a doorway 3 blocks tall through walls. */
	private static void carve(int x1, int z1, int x2, int z2) {
		fill(x1, FLOOR_Y + 1, z1, x2, FLOOR_Y + 3, z2, AIR);
	}

	private static Container chest(int x, int y, int z, BlockState state) {
		set(x, y, z, state);
		if (level.getBlockEntity(new BlockPos(ox + x, y, oz + z)) instanceof Container c) {
			return c;
		}
		return null;
	}

	private static BlockState chestState() {
		return Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.SOUTH);
	}

	private static void put(Container c, int slot, ItemStack s) {
		if (c != null && slot < c.getContainerSize()) {
			c.setItem(slot, s);
		}
	}

	private static ItemStack paper(String title, String text) {
		ItemStack s = new ItemStack(Items.PAPER);
		s.set(DataComponents.CUSTOM_NAME, Component.literal(title));
		s.set(DataComponents.LORE, new ItemLore(List.of(Component.literal(text))));
		return s;
	}

	private static void display(double x, int y, double z, ItemStack stack, String label) {
		BlockPos at = new BlockPos(ox + (int) Math.floor(x), y, oz + (int) Math.floor(z));
		level.getEntitiesOfClass(ItemEntity.class, new AABB(at).inflate(0.4)).forEach(ItemEntity::discard);
		ItemEntity e = new ItemEntity(level, ox + x, y + 0.4, oz + z, stack);
		e.setDeltaMovement(Vec3.ZERO);
		e.setNoGravity(true);
		e.setPickUpDelay(32767);
		e.setUnlimitedLifetime();
		e.setCustomName(Component.literal(label));
		e.setCustomNameVisible(true);
		level.addFreshEntity(e);
	}

	// ----- control room and labs -----

	private static void controlRoom() {
		shell(-26, 26, -6, 46, Blocks.DEEPSLATE_BRICKS.defaultBlockState(),
				Blocks.POLISHED_ANDESITE.defaultBlockState());
		int cx = -16;
		int cz = 36;
		fill(cx - 1, FLOOR_Y + 1, cz - 1, cx + 1, FLOOR_Y + 3, cz + 1, Blocks.SEA_LANTERN.defaultBlockState());
		for (int[] d : new int[][] {{4, 0}, {-4, 0}, {0, 4}, {0, -4}}) {
			set(cx + d[0], FLOOR_Y + 1, cz + d[1], ModTech.BLOCKS.get("ubtm_terminal").defaultBlockState());
		}
		Container guide = chest(cx, FLOOR_Y + 1, 29, chestState());
		put(guide, 0, paper("UBTM HQ Guide", "Commands: /ubtm hq, help, quests, test, reload. Labs are west, rooms east."));
		put(guide, 1, paper("Layout", "East corridors: pickaxe rooms, sword rooms, armour rooms (25 each)."));
		put(guide, 2, paper("Survival", "Finish 10 quests to unlock HQ. Craft items or earn them from quests."));
	}

	private static void lab(int i) {
		int hi = -28 - 14 * i;
		int lo = hi - 12;
		int cx = (lo + hi) / 2;
		String[] names = {"Pickaxe Laboratory", "Sword Laboratory", "Armour Laboratory",
				"Technology Laboratory", "Quest Laboratory"};
		shell(lo, 22, hi, 34, Blocks.POLISHED_DEEPSLATE.defaultBlockState(),
				Blocks.SMOOTH_QUARTZ.defaultBlockState());
		carve(cx - 1, 34, cx + 1, 34);
		set(cx, FLOOR_Y + 1, 23, ModTech.BLOCKS.get("ubtm_terminal").defaultBlockState());
		Container info = chest(lo + 1, FLOOR_Y + 1, 33, chestState());
		put(info, 0, paper(names[i], "Use the terminal to open the UBTM menu."));
		List<Item> items = new ArrayList<>();
		if (i == 0) {
			items.addAll(ModItems.PICKAXES.values());
		} else if (i == 1) {
			items.addAll(ModSwords.SWORDS.values());
		} else if (i == 3) {
			items.addAll(ModTech.ITEMS);
		}
		if (creativeBuild && i <= 3 && i != 2) {
			Container c = chest(cx, FLOOR_Y + 1, 28, chestState());
			for (int s = 0; s < items.size(); s++) {
				put(c, s, new ItemStack(items.get(s)));
			}
		}
		if (i == 2 && creativeBuild) {
			for (int piece = 0; piece < 4; piece++) {
				Container c = chest(lo + 2 + piece * 2, FLOOR_Y + 1, 28, chestState());
				for (int s = 0; s < ModArmor.SETS.size(); s++) {
					put(c, s, new ItemStack(ModArmor.SETS.get(s).pieces().get(piece)));
				}
			}
		}
		if (i == 3) {
			Container c = chest(hi - 2, FLOOR_Y + 1, 33, chestState());
			put(c, 0, new ItemStack(Items.RAW_IRON, 32));
			put(c, 1, new ItemStack(Items.RAW_GOLD, 32));
			put(c, 2, new ItemStack(Items.SAND, 64));
			put(c, 3, new ItemStack(Items.COBBLESTONE, 64));
			put(c, 4, new ItemStack(Items.REDSTONE_TORCH, 8));
		}
		if (i == 4) {
			Container c = chest(hi - 2, FLOOR_Y + 1, 33, chestState());
			put(c, 0, paper("Quest Lab", "50 quests: mining, crafting, collection, technology. Open Quests in the menu."));
		}
	}

	// ----- the 75 test rooms -----

	private static void toolRoom(int kind, int k) {
		int zc = 30 * kind;
		int x0 = SPACING * k + 1;
		BlockState wall = switch (kind) {
			case 0 -> Blocks.STONE_BRICKS.defaultBlockState();
			case 1 -> Blocks.NETHER_BRICKS.defaultBlockState();
			default -> Blocks.PRISMARINE_BRICKS.defaultBlockState();
		};
		BlockState floor = switch (kind) {
			case 0 -> Blocks.SMOOTH_STONE.defaultBlockState();
			case 1 -> Blocks.RED_CONCRETE.defaultBlockState();
			default -> Blocks.BLUE_TERRACOTTA.defaultBlockState();
		};
		shell(x0, zc - 2, x0 + 10, zc + 8, wall, floor);
		carve(x0 + 4, zc + 8, x0 + 6, zc + 8);
		fill(x0 + 4, FLOOR_Y, zc + 8, x0 + 6, FLOOR_Y, zc + 8, floor);

		String id;
		String name;
		String desc;
		List<Item> showcase = new ArrayList<>();
		if (kind == 0) {
			id = new ArrayList<>(ModItems.PICKAXES.keySet()).get(k);
			name = Info.name(id);
			desc = Info.DESC.get(id);
			showcase.add(ModItems.PICKAXES.get(id));
		} else if (kind == 1) {
			id = new ArrayList<>(ModSwords.SWORDS.keySet()).get(k);
			name = Info.name(id);
			desc = Info.DESC.get(id);
			showcase.add(ModSwords.SWORDS.get(id));
		} else {
			ArmorSet set = ModArmor.SETS.get(k);
			id = set.id();
			name = set.name();
			desc = set.desc();
			showcase.addAll(set.pieces());
		}

		// item display on pedestals (items hover and cannot be picked up)
		BlockState pedestal = Blocks.QUARTZ_BLOCK.defaultBlockState();
		for (int i = 0; i < showcase.size(); i++) {
			int px = showcase.size() == 1 ? x0 + 5 : x0 + 2 + i * 2;
			set(px, FLOOR_Y + 1, zc + 5, pedestal);
			String label = showcase.size() == 1 ? name + ": " + desc : (i == 0 ? name + ": " + desc : name);
			display(px + 0.5, FLOOR_Y + 2, zc + 5.5, new ItemStack(showcase.get(i)), label);
		}

		// ability information
		Container infoBarrel = chest(x0 + 1, FLOOR_Y + 1, zc + 7, chestState());
		put(infoBarrel, 0, paper(name, desc));

		// testing equipment
		Container tools = chest(x0 + 9, FLOOR_Y + 1, zc + 7, chestState());
		testingEquipment(tools, kind, showcase);

		// testing area
		testingArea(kind, x0, zc, k);
	}

	private static void testingEquipment(Container c, int kind, List<Item> showcase) {
		if (kind == 0) {
			put(c, 0, new ItemStack(Items.RAW_IRON, 32));
			put(c, 1, new ItemStack(Items.RAW_GOLD, 32));
			put(c, 2, new ItemStack(Items.RAW_COPPER, 32));
			put(c, 3, new ItemStack(Items.COBBLESTONE, 64));
			put(c, 4, new ItemStack(Items.SAND, 64));
			put(c, 5, new ItemStack(Items.TORCH, 32));
			put(c, 6, new ItemStack(Items.BREAD, 32));
			put(c, 7, new ItemStack(Items.GOLDEN_APPLE, 4));
		} else if (kind == 1) {
			put(c, 0, new ItemStack(Items.ZOMBIE_SPAWN_EGG, 16));
			put(c, 1, new ItemStack(Items.SKELETON_SPAWN_EGG, 8));
			put(c, 2, new ItemStack(Items.SPIDER_SPAWN_EGG, 8));
			put(c, 3, new ItemStack(Items.HUSK_SPAWN_EGG, 8));
			put(c, 4, new ItemStack(Items.COOKED_BEEF, 32));
			put(c, 5, new ItemStack(Items.GOLDEN_APPLE, 8));
		} else {
			put(c, 0, new ItemStack(Items.GOLDEN_APPLE, 8));
			put(c, 1, new ItemStack(Items.COOKED_BEEF, 32));
			put(c, 2, new ItemStack(Items.WATER_BUCKET, 1));
			put(c, 3, new ItemStack(Items.ZOMBIE_SPAWN_EGG, 8));
			put(c, 4, new ItemStack(Items.SKELETON_SPAWN_EGG, 8));
		}
		if (creativeBuild) {
			int slot = 9;
			for (Item it : showcase) {
				put(c, slot++, new ItemStack(it));
			}
		}
	}

	private static void testingArea(int kind, int x0, int zc, int k) {
		if (kind == 0) {
			BlockState[] mix = {
					Blocks.STONE.defaultBlockState(), Blocks.COAL_ORE.defaultBlockState(),
					Blocks.IRON_ORE.defaultBlockState(), Blocks.STONE.defaultBlockState(),
					Blocks.GOLD_ORE.defaultBlockState(), Blocks.DIAMOND_ORE.defaultBlockState(),
					Blocks.REDSTONE_ORE.defaultBlockState(), Blocks.DEEPSLATE.defaultBlockState(),
					Blocks.COPPER_ORE.defaultBlockState(), Blocks.OAK_LOG.defaultBlockState(),
					Blocks.LAPIS_ORE.defaultBlockState(), Blocks.EMERALD_ORE.defaultBlockState(),
					Blocks.COBBLESTONE.defaultBlockState(), Blocks.SAND.defaultBlockState()};
			for (int x = x0 + 1; x <= x0 + 9; x++) {
				for (int y = 1; y <= 3; y++) {
					for (int z = zc - 1; z <= zc + 1; z++) {
						set(x, FLOOR_Y + y, z, mix[Math.floorMod(x * 7 + y * 3 + z * 5 + k, mix.length)]);
					}
				}
			}
		} else if (kind == 1) {
			fill(x0 + 1, FLOOR_Y, zc - 1, x0 + 9, FLOOR_Y, zc + 2, Blocks.BLACK_CONCRETE.defaultBlockState());
			fill(x0 + 1, FLOOR_Y + 1, zc + 3, x0 + 9, FLOOR_Y + 1, zc + 3, Blocks.OAK_FENCE.defaultBlockState());
		} else {
			// hazards: lava, water, fire, magma, powder snow, cactus
			fill(x0 + 1, FLOOR_Y, zc - 1, x0 + 2, FLOOR_Y, zc, Blocks.LAVA.defaultBlockState());
			fill(x0 + 4, FLOOR_Y, zc - 1, x0 + 5, FLOOR_Y, zc, Blocks.WATER.defaultBlockState());
			fill(x0 + 7, FLOOR_Y, zc - 1, x0 + 8, FLOOR_Y, zc, Blocks.MAGMA_BLOCK.defaultBlockState());
			set(x0 + 7, FLOOR_Y + 1, zc + 2, Blocks.NETHERRACK.defaultBlockState());
			set(x0 + 7, FLOOR_Y + 2, zc + 2, Blocks.FIRE.defaultBlockState());
			set(x0 + 4, FLOOR_Y, zc + 2, Blocks.POWDER_SNOW.defaultBlockState());
			set(x0 + 2, FLOOR_Y, zc + 2, Blocks.SAND.defaultBlockState());
			set(x0 + 2, FLOOR_Y + 1, zc + 2, Blocks.CACTUS.defaultBlockState());
		}
	}
}
