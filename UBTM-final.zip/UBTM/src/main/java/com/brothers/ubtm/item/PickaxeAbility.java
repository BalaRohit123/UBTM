package com.brothers.ubtm.item;

import com.brothers.ubtm.util.BreakUtil;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** One special ability per pickaxe. Runs after the player breaks a block with that pickaxe. */
public enum PickaxeAbility {
	VEIN_MINER, HAMMER, TUNNEL, SMELTER, MAGNET, HASTE, LUMBER, NIGHT_VISION, XP_BOOST, LUCKY,
	TORCH, HEAL, SPEED, JUMP, FIRE_RESIST, WATER_BREATH, EXCAVATOR, SCANNER, GLOW, COLUMN_UP,
	COLUMN_DOWN, REPAIR, RESIST, TREASURE, FIRE_AURA;

	public void apply(ServerLevel level, ServerPlayer player, BlockPos pos, BlockState state,
			BlockEntity be, ItemStack tool) {
		switch (this) {
			case VEIN_MINER -> {
				if (BreakUtil.isOre(state)) {
					BreakUtil.breakConnected(level, player, pos, state, tool, 24);
				}
			}
			case HAMMER -> {
				Direction dir = BreakUtil.lookDirection(player);
				for (BlockPos p : BreakUtil.plane(pos, dir.getAxis(), 1)) {
					BreakUtil.breakExtra(level, player, p, tool);
				}
			}
			case TUNNEL -> {
				Direction dir = BreakUtil.lookDirection(player);
				for (int i = 1; i <= 5; i++) {
					BreakUtil.breakExtra(level, player, pos.relative(dir, i), tool);
				}
			}
			case SMELTER -> smelt(level, pos);
			case MAGNET -> {
				for (ItemEntity e : items(level, pos)) {
					e.setPos(player.getX(), player.getY(), player.getZ());
					e.setNoPickUpDelay();
				}
			}
			case HASTE -> player.addEffect(new MobEffectInstance(MobEffects.HASTE, 100, 1));
			case LUMBER -> {
				if (state.is(BlockTags.LOGS)) {
					BreakUtil.breakConnected(level, player, pos, state, tool, 64);
				}
			}
			case NIGHT_VISION ->
				player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0));
			case XP_BOOST -> ExperienceOrb.award(level, Vec3.atCenterOf(pos), 3);
			case LUCKY -> {
				if (level.getRandom().nextFloat() < 0.10f && tool.isCorrectToolForDrops(state)) {
					for (ItemStack s : Block.getDrops(state, level, pos, be, player, tool)) {
						Block.popResource(level, pos, s);
					}
				}
			}
			case TORCH -> {
				if (level.getBlockState(pos).isAir()
						&& level.getMaxLocalRawBrightness(pos) < 7
						&& Blocks.TORCH.defaultBlockState().canSurvive(level, pos)) {
					level.setBlockAndUpdate(pos, Blocks.TORCH.defaultBlockState());
				}
			}
			case HEAL -> player.heal(1.0f);
			case SPEED -> player.addEffect(new MobEffectInstance(MobEffects.SPEED, 60, 1));
			case JUMP -> player.addEffect(new MobEffectInstance(MobEffects.JUMP_BOOST, 100, 1));
			case FIRE_RESIST ->
				player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 200, 0));
			case WATER_BREATH ->
				player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 200, 0));
			case EXCAVATOR -> {
				for (int x = -1; x <= 1; x++) {
					for (int y = -1; y <= 1; y++) {
						for (int z = -1; z <= 1; z++) {
							if (x != 0 || y != 0 || z != 0) {
								BreakUtil.breakExtra(level, player, pos.offset(x, y, z), tool);
							}
						}
					}
				}
			}
			case SCANNER -> {
				int count = 0;
				for (BlockPos p : BlockPos.betweenClosed(pos.offset(-8, -8, -8), pos.offset(8, 8, 8))) {
					String path = BuiltInRegistries.BLOCK.getKey(level.getBlockState(p).getBlock())
							.getPath();
					if (path.endsWith("_ore")) {
						count++;
					}
				}
				if (com.brothers.ubtm.data.PlayerDataStore.get(player).messages) {
					player.sendSystemMessage(Component.literal("Ores within 8 blocks: " + count), true);
				}
			}
			case GLOW -> {
				AABB box = player.getBoundingBox().inflate(12);
				for (Monster m : level.getEntitiesOfClass(Monster.class, box)) {
					m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
				}
			}
			case COLUMN_UP -> {
				for (int i = 1; i <= 4; i++) {
					BreakUtil.breakExtra(level, player, pos.above(i), tool);
				}
			}
			case COLUMN_DOWN -> {
				for (int i = 1; i <= 4; i++) {
					BreakUtil.breakExtra(level, player, pos.below(i), tool);
				}
			}
			case REPAIR -> {
				if (level.getRandom().nextFloat() < 0.10f) {
					tool.setDamageValue(Math.max(0, tool.getDamageValue() - 2));
				}
			}
			case RESIST ->
				player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 100, 0));
			case TREASURE -> {
				if (level.getRandom().nextFloat() < 0.02f) {
					Block.popResource(level, pos, new ItemStack(Items.DIAMOND));
				}
			}
			case FIRE_AURA -> {
				AABB box = player.getBoundingBox().inflate(6);
				for (Monster m : level.getEntitiesOfClass(Monster.class, box)) {
					m.igniteForSeconds(4);
				}
			}
		}
	}

	private static List<ItemEntity> items(ServerLevel level, BlockPos pos) {
		return level.getEntitiesOfClass(ItemEntity.class, new AABB(pos).inflate(1.5));
	}

	private static void smelt(ServerLevel level, BlockPos pos) {
		for (ItemEntity e : items(level, pos)) {
			ItemStack s = e.getItem();
			ItemStack out = null;
			if (s.is(Items.RAW_IRON)) {
				out = new ItemStack(Items.IRON_INGOT, s.getCount());
			} else if (s.is(Items.RAW_GOLD)) {
				out = new ItemStack(Items.GOLD_INGOT, s.getCount());
			} else if (s.is(Items.RAW_COPPER)) {
				out = new ItemStack(Items.COPPER_INGOT, s.getCount());
			} else if (s.is(Items.COBBLESTONE)) {
				out = new ItemStack(Items.STONE, s.getCount());
			} else if (s.is(Items.SAND)) {
				out = new ItemStack(Items.GLASS, s.getCount());
			}
			if (out != null) {
				e.setItem(out);
			}
		}
	}
}
