package com.brothers.ubtm.data;

import com.brothers.ubtm.UBTM;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;

/** Saves one JSON file per player in the world folder: <world>/ubtm/<uuid>.json */
public final class PlayerDataStore {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Map<UUID, PlayerData> CACHE = new HashMap<>();

	private PlayerDataStore() {}

	private static Path file(MinecraftServer server, UUID id) {
		return server.getWorldPath(LevelResource.ROOT).resolve("ubtm").resolve(id + ".json");
	}

	public static PlayerData get(ServerPlayer player) {
		return CACHE.computeIfAbsent(player.getUUID(), id -> load(player.level().getServer(), id));
	}

	private static PlayerData load(MinecraftServer server, UUID id) {
		Path f = file(server, id);
		try {
			if (Files.exists(f)) {
				PlayerData d = GSON.fromJson(Files.readString(f), PlayerData.class);
				if (d != null) {
					return d;
				}
			}
		} catch (IOException | JsonParseException e) {
			UBTM.LOGGER.error("Could not read player data {}", f, e);
		}
		return new PlayerData();
	}

	public static void save(MinecraftServer server, UUID id) {
		PlayerData d = CACHE.get(id);
		if (d == null) {
			return;
		}
		Path f = file(server, id);
		try {
			Files.createDirectories(f.getParent());
			Files.writeString(f, GSON.toJson(d));
		} catch (IOException e) {
			UBTM.LOGGER.error("Could not save player data {}", f, e);
		}
	}

	public static void saveAll(MinecraftServer server) {
		for (UUID id : CACHE.keySet()) {
			save(server, id);
		}
	}

	public static void unload(MinecraftServer server, UUID id) {
		save(server, id);
		CACHE.remove(id);
	}

	/** Used by /ubtm reload: write everything, then forget the cache so files are re-read. */
	public static void reload(MinecraftServer server) {
		saveAll(server);
		CACHE.clear();
	}
}
