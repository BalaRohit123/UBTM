package com.brothers.ubtm.data;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** Everything UBTM saves per player (quest progress, counters, settings). */
public class PlayerData {
	public Set<String> completed = new LinkedHashSet<>();
	public Map<String, Integer> baseline = new HashMap<>();
	public Map<String, Integer> counters = new HashMap<>();
	public boolean abilities = true;
	public boolean messages = true;

	public void count(String key) {
		counters.merge(key, 1, Integer::sum);
	}
}
