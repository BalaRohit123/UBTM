package com.brothers.ubtm.armor;

import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.Item;

/** One armour set: four pieces plus the effects granted while all four are worn. */
public record ArmorSet(String id, String name, String desc, List<Eff> effects, List<Item> pieces) {

	public record Eff(Holder<MobEffect> effect, int amplifier) {}

	public void applyTo(ServerPlayer player) {
		for (Eff e : effects) {
			player.addEffect(new MobEffectInstance(e.effect(), 260, e.amplifier(), true, false, true));
		}
	}
}
