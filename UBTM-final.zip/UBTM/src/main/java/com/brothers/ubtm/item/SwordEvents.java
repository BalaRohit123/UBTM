package com.brothers.ubtm.item;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public final class SwordEvents {
	private SwordEvents() {}

	public static void register() {
		AttackEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
			if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer sp
					&& entity instanceof LivingEntity target) {
				if (!com.brothers.ubtm.data.PlayerDataStore.get(sp).abilities) {
					return InteractionResult.PASS;
				}
				ItemStack stack = sp.getItemInHand(hand);
				SwordAbility ability = ModSwords.SWORD_ABILITIES.get(stack.getItem());
				if (ability != null) {
					ability.apply(serverLevel, sp, target);
				}
			}
			return InteractionResult.PASS;
		});
	}
}
