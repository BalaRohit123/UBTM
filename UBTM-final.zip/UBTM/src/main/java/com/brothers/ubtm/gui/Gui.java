package com.brothers.ubtm.gui;

import com.brothers.ubtm.armor.ArmorSet;
import com.brothers.ubtm.armor.ModArmor;
import com.brothers.ubtm.data.PlayerData;
import com.brothers.ubtm.data.PlayerDataStore;
import com.brothers.ubtm.item.Info;
import com.brothers.ubtm.item.ModItems;
import com.brothers.ubtm.item.ModSwords;
import com.brothers.ubtm.quest.Quest;
import com.brothers.ubtm.quest.QuestDefs;
import com.brothers.ubtm.quest.QuestManager;
import com.brothers.ubtm.tech.ModTech;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/** The UBTM menu: PICKAXES, SWORDS, ARMOUR, TECHNOLOGY, QUESTS, SETTINGS. */
public final class Gui {
	private Gui() {}

	private static ItemStack named(Item item, String name, ChatFormatting color, List<String> lore) {
		ItemStack s = new ItemStack(item);
		s.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(color));
		List<Component> lines = new ArrayList<>();
		for (String l : lore) {
			lines.add(Component.literal(l).withStyle(ChatFormatting.GRAY));
		}
		s.set(DataComponents.LORE, new ItemLore(lines));
		return s;
	}

	private static void open(ServerPlayer sp, String title, int rows, SimpleContainer c,
			Map<Integer, Consumer<ServerPlayer>> actions) {
		sp.openMenu(new SimpleMenuProvider((id, inv, p) -> new UbtmMenu(id, inv, c, rows, actions),
				Component.literal(title)));
	}

	public static void openMain(ServerPlayer sp) {
		SimpleContainer c = new SimpleContainer(27);
		Map<Integer, Consumer<ServerPlayer>> a = new HashMap<>();
		c.setItem(10, named(Items.DIAMOND_PICKAXE, "PICKAXES", ChatFormatting.AQUA, List.of("25 custom pickaxes")));
		a.put(10, Gui::openPickaxes);
		c.setItem(11, named(Items.DIAMOND_SWORD, "SWORDS", ChatFormatting.RED, List.of("25 custom swords")));
		a.put(11, Gui::openSwords);
		c.setItem(12, named(Items.DIAMOND_CHESTPLATE, "ARMOUR", ChatFormatting.BLUE, List.of("25 armour sets")));
		a.put(12, Gui::openArmour);
		c.setItem(14, named(Items.PISTON, "TECHNOLOGY", ChatFormatting.GOLD, List.of("Machines and tools")));
		a.put(14, Gui::openTech);
		c.setItem(15, named(Items.WRITABLE_BOOK, "QUESTS", ChatFormatting.GREEN, List.of("50 quests")));
		a.put(15, Gui::openQuests);
		c.setItem(16, named(Items.COMPARATOR, "SETTINGS", ChatFormatting.YELLOW, List.of("Toggle abilities and messages")));
		a.put(16, Gui::openSettings);
		open(sp, "UBTM", 3, c, a);
	}

	private static void back(SimpleContainer c, Map<Integer, Consumer<ServerPlayer>> a, int slot) {
		c.setItem(slot, named(Items.ARROW, "BACK", ChatFormatting.WHITE, List.of()));
		a.put(slot, Gui::openMain);
	}

	private static String hint(ServerPlayer sp) {
		return sp.isCreative() ? "Click to take it (Creative)" : "Craft it or earn it from quests (Survival)";
	}

	private static void showItems(ServerPlayer sp, String title, List<Item> items) {
		SimpleContainer c = new SimpleContainer(54);
		Map<Integer, Consumer<ServerPlayer>> a = new HashMap<>();
		for (int i = 0; i < items.size() && i < 45; i++) {
			Item item = items.get(i);
			ItemStack icon = new ItemStack(item);
			List<Component> lore = new ArrayList<>();
			String key = BuiltInRegistries.ITEM.getKey(item).getPath();
			String desc = Info.DESC.get(key);
			if (desc != null) {
				lore.add(Component.literal(desc).withStyle(ChatFormatting.GRAY));
			}
			lore.add(Component.literal(hint(sp)).withStyle(ChatFormatting.DARK_GRAY));
			icon.set(DataComponents.LORE, new ItemLore(lore));
			c.setItem(i, icon);
			a.put(i, p -> {
				if (p.isCreative()) {
					p.addItem(new ItemStack(item));
				} else {
					p.sendSystemMessage(Component.literal(Info.name(key) + ": " + (desc == null ? "" : desc)));
				}
			});
		}
		back(c, a, 49);
		open(sp, title, 6, c, a);
	}

	public static void openPickaxes(ServerPlayer sp) {
		showItems(sp, "Pickaxes", ModItems.allPickaxes());
	}

	public static void openSwords(ServerPlayer sp) {
		showItems(sp, "Swords", new ArrayList<>(ModSwords.SWORDS.values()));
	}

	public static void openTech(ServerPlayer sp) {
		showItems(sp, "Technology", ModTech.ITEMS);
	}

	public static void openArmour(ServerPlayer sp) {
		SimpleContainer c = new SimpleContainer(54);
		Map<Integer, Consumer<ServerPlayer>> a = new HashMap<>();
		for (int i = 0; i < ModArmor.SETS.size(); i++) {
			ArmorSet set = ModArmor.SETS.get(i);
			ItemStack icon = new ItemStack(set.pieces().get(1));
			icon.set(DataComponents.CUSTOM_NAME, Component.literal(set.name()).withStyle(ChatFormatting.AQUA));
			icon.set(DataComponents.LORE, new ItemLore(List.of(
					Component.literal(set.desc()).withStyle(ChatFormatting.GRAY),
					Component.literal(sp.isCreative() ? "Click to take the full set (Creative)"
							: "Craft the pieces (Survival)").withStyle(ChatFormatting.DARK_GRAY))));
			c.setItem(i, icon);
			a.put(i, p -> {
				if (p.isCreative()) {
					for (Item piece : set.pieces()) {
						p.addItem(new ItemStack(piece));
					}
				} else {
					p.sendSystemMessage(Component.literal(set.name() + ": " + set.desc()));
				}
			});
		}
		back(c, a, 49);
		open(sp, "Armour", 6, c, a);
	}

	public static void openQuests(ServerPlayer sp) {
		PlayerData d = PlayerDataStore.get(sp);
		SimpleContainer c = new SimpleContainer(54);
		Map<Integer, Consumer<ServerPlayer>> a = new HashMap<>();
		for (int i = 0; i < QuestDefs.ALL.size() && i < 50; i++) {
			Quest q = QuestDefs.ALL.get(i);
			boolean done = d.completed.contains(q.id());
			int prog = Math.min(q.count(), QuestManager.progress(sp, d, q));
			List<String> lore = new ArrayList<>();
			lore.add(q.category() + " quest");
			lore.add(q.desc());
			lore.add(done ? "Completed" : "Progress: " + prog + " / " + q.count());
			for (Quest.Reward r : q.rewards()) {
				lore.add("Reward: " + r.count() + " x " + new ItemStack(QuestManager.item(r.item())).getHoverName().getString());
			}
			c.setItem(i, named(done ? Items.LIME_DYE : Items.GRAY_DYE, (i + 1) + ". " + q.title(),
					done ? ChatFormatting.GREEN : ChatFormatting.WHITE, lore));
		}
		back(c, a, 53);
		open(sp, "Quests (" + d.completed.size() + "/50)", 6, c, a);
	}

	public static void openSettings(ServerPlayer sp) {
		PlayerData d = PlayerDataStore.get(sp);
		SimpleContainer c = new SimpleContainer(27);
		Map<Integer, Consumer<ServerPlayer>> a = new HashMap<>();
		c.setItem(11, named(d.abilities ? Items.LIME_DYE : Items.RED_DYE,
				"Abilities: " + (d.abilities ? "ON" : "OFF"), ChatFormatting.WHITE,
				List.of("Turns pickaxe, sword and armour abilities on or off", "Click to toggle")));
		a.put(11, p -> {
			PlayerData pd = PlayerDataStore.get(p);
			pd.abilities = !pd.abilities;
			openSettings(p);
		});
		c.setItem(15, named(d.messages ? Items.LIME_DYE : Items.RED_DYE,
				"Messages: " + (d.messages ? "ON" : "OFF"), ChatFormatting.WHITE,
				List.of("Action-bar messages from abilities", "Click to toggle")));
		a.put(15, p -> {
			PlayerData pd = PlayerDataStore.get(p);
			pd.messages = !pd.messages;
			openSettings(p);
		});
		back(c, a, 22);
		open(sp, "Settings", 3, c, a);
	}
}
