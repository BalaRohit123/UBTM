package com.brothers.ubtm.item;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** One special ability per sword. Runs when the player attacks a living target with that sword. */
public enum SwordAbility {
	FIRE, FREEZE, POISON, WITHER, LIFESTEAL, KNOCKBACK, BLIND, WEAKEN, GLOW, LEVITATE,
	NAUSEA, HUNGER, BERSERK, SWIFT, GUARD, REGEN, EXECUTE, CRIT, CLEAVE, SHOCKWAVE,
	SLOW, FATIGUE, GHOST, XP_THIEF, FIRE_NOVA;

	public void apply(ServerLevel level, ServerPlayer player, LivingEntity target) {
		switch (this) {
			case FIRE -> target.igniteForSeconds(6);
			case FREEZE -> {
				target.setTicksFrozen(target.getTicksRequiredToFreeze() + 100);
				target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 100, 1));
			}
			case POISON -> target.addEffect(new MobEffectInstance(MobEffects.POISON, 120, 1));
			case WITHER -> target.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));
			case LIFESTEAL -> player.heal(2.0f);
			case KNOCKBACK -> push(player, target, 1.6);
			case BLIND -> target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 0));
			case WEAKEN -> target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
			case GLOW -> target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 400, 0));
			case LEVITATE -> target.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 60, 0));
			case NAUSEA -> target.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 200, 0));
			case HUNGER -> target.addEffect(new MobEffectInstance(MobEffects.HUNGER, 200, 2));
			case BERSERK -> player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 100, 1));
			case SWIFT -> player.addEffect(new MobEffectInstance(MobEffects.SPEED, 100, 1));
			case GUARD -> player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 1));
			case REGEN -> player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
			case EXECUTE -> {
				if (target.getHealth() < target.getMaxHealth() * 0.3f) {
					extra(level, player, target, 6.0f);
				}
			}
			case CRIT -> {
				if (level.getRandom().nextFloat() < 0.25f) {
					extra(level, player, target, 4.0f);
				}
			}
			case CLEAVE -> {
				AABB box = target.getBoundingBox().inflate(3);
				int hits = 0;
				for (Monster m : level.getEntitiesOfClass(Monster.class, box)) {
					if (m != target && hits < 3) {
						extra(level, player, m, 3.0f);
						hits++;
					}
				}
			}
			case SHOCKWAVE -> {
				AABB box = player.getBoundingBox().inflate(5);
				for (Monster m : level.getEntitiesOfClass(Monster.class, box)) {
					push(player, m, 1.0);
				}
			}
			case SLOW -> target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 160, 3));
			case FATIGUE -> target.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, 200, 1));
			case GHOST -> player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 100, 0));
			case XP_THIEF -> ExperienceOrb.award(level, Vec3.atCenterOf(target.blockPosition()), 4);
			case FIRE_NOVA -> {
				AABB box = player.getBoundingBox().inflate(5);
				for (Monster m : level.getEntitiesOfClass(Monster.class, box)) {
					m.igniteForSeconds(5);
				}
			}
		}
	}

	private static void push(ServerPlayer player, LivingEntity target, double strength) {
		double dx = target.getX() - player.getX();
		double dz = target.getZ() - player.getZ();
		target.knockback(strength, -dx, -dz);
	}

	private static void extra(ServerLevel level, ServerPlayer player, LivingEntity target,
			float amount) {
		target.hurtServer(level, level.damageSources().playerAttack(player), amount);
	}
}
